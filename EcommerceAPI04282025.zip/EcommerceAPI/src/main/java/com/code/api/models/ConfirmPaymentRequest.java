package com.code.api.models;


	public class ConfirmPaymentRequest {
	    private String razorpayOrderId;
	    private String razorpayPaymentId;
		public String getRazorpayOrderId() {
			return razorpayOrderId;
		}
		public void setRazorpayOrderId(String razorpayOrderId) {
			this.razorpayOrderId = razorpayOrderId;
		}
		public String getRazorpayPaymentId() {
			return razorpayPaymentId;
		}
		public void setRazorpayPaymentId(String razorpayPaymentId) {
			this.razorpayPaymentId = razorpayPaymentId;
		}
		
	}

